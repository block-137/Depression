package net.depression.forge;

import dev.architectury.platform.forge.EventBuses;
import net.depression.Depression;
import net.depression.forge.config.ServerConfig;
import net.depression.forge.world.ForgeVillageAddition;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.spongepowered.asm.mixin.Mixin;

@Mod(Depression.MOD_ID)
public final class DepressionForge {
    public DepressionForge() {
        // Submit our event bus to let Architectury API register our content on the right time.
        EventBuses.registerModEventBus(Depression.MOD_ID, FMLJavaModLoadingContext.get().getModEventBus());
        // Run our common setup.
        Depression.init();
        ForgeVillageAddition.register();
        ServerConfig.load();
    }

}
