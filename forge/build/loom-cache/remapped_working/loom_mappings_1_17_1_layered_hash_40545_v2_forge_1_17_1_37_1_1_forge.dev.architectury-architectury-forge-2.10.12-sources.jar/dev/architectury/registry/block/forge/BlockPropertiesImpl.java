/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.registry.block.forge;

import dev.architectury.registry.block.BlockProperties;
import dev.architectury.registry.block.ToolType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Material;
import net.minecraft.world.level.material.MaterialColor;

import java.util.function.Function;

public class BlockPropertiesImpl {
    public static BlockProperties of(Material material, MaterialColor materialColor) {
        return new Impl(material, (state) -> materialColor);
    }
    
    public static BlockProperties of(Material material, Function<BlockState, MaterialColor> function) {
        return new Impl(material, function);
    }
    
    public static BlockProperties copy(BlockBehaviour abstractBlock) {
        return copy(abstractBlock.f_60439_);
    }
    
    public static BlockProperties copy(BlockBehaviour.Properties old) {
        BlockProperties properties = of(old.f_60882_, old.f_60883_);
        properties.f_60882_ = old.f_60882_;
        properties.f_60888_ = old.f_60888_;
        properties.f_60887_ = old.f_60887_;
        properties.f_60884_ = old.f_60884_;
        properties.f_60890_ = old.f_60890_;
        properties.f_60886_ = old.f_60886_;
        properties.f_60883_ = old.f_60883_;
        properties.f_60885_ = old.f_60885_;
        properties.f_60891_ = old.f_60891_;
        properties.f_60892_ = old.f_60892_;
        properties.f_60903_ = old.f_60903_;
        properties.f_60895_ = old.f_60895_;
        properties.f_60896_ = old.f_60896_;
        properties.f_60889_ = old.f_60889_;
        return properties;
    }
    
    private static final class Impl extends BlockProperties {
        public Impl(Material material, Function<BlockState, MaterialColor> function) {
            super(material, function);
        }
        
        @Override
        @Deprecated
        public BlockProperties tool(ToolType type, int level) {
            return this;
        }
    }
}
