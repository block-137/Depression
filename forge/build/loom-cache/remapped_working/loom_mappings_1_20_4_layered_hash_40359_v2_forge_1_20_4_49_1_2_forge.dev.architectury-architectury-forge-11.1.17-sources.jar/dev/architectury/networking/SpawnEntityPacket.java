/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.networking;

import D;
import F;
import I;
import dev.architectury.extensions.network.EntitySpawnExtension;
import io.netty.buffer.Unpooled;
import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.phys.Vec3;

/**
 * @see net.minecraft.network.protocol.game.ClientboundAddEntityPacket
 */
public class SpawnEntityPacket {
    private static final ResourceLocation PACKET_ID = new ResourceLocation("architectury", "spawn_entity_packet");
    
    public static Packet<ClientGamePacketListener> create(Entity entity) {
        if (entity.m_9236_().m_5776_()) {
            throw new IllegalStateException("SpawnPacketUtil.create called on the logical client!");
        }
        var buffer = new FriendlyByteBuf(Unpooled.buffer());
        buffer.m_130130_(BuiltInRegistries.f_256780_.m_7447_(entity.m_6095_()));
        buffer.m_130077_(entity.m_20148_());
        buffer.m_130130_(entity.m_19879_());
        var position = entity.m_20182_();
        buffer.writeDouble(position.f_82479_);
        buffer.writeDouble(position.f_82480_);
        buffer.writeDouble(position.f_82481_);
        buffer.writeFloat(entity.m_146909_());
        buffer.writeFloat(entity.m_146908_());
        buffer.writeFloat(entity.m_6080_());
        var deltaMovement = entity.m_20184_();
        buffer.writeDouble(deltaMovement.f_82479_);
        buffer.writeDouble(deltaMovement.f_82480_);
        buffer.writeDouble(deltaMovement.f_82481_);
        if (entity instanceof EntitySpawnExtension ext) {
            ext.saveAdditionalSpawnData(buffer);
        }
        return (Packet<ClientGamePacketListener>) NetworkManager.toPacket(NetworkManager.s2c(), PACKET_ID, buffer);
    }
    
    
    @Environment(EnvType.CLIENT)
    public static class Client {
        @Environment(EnvType.CLIENT)
        public static void register() {
            NetworkManager.registerReceiver(NetworkManager.s2c(), PACKET_ID, Client::receive);
        }
        
        @Environment(EnvType.CLIENT)
        public static void receive(FriendlyByteBuf buf, NetworkManager.PacketContext context) {
            var entityTypeId = buf.m_130242_();
            var uuid = buf.m_130259_();
            var id = buf.m_130242_();
            var x = buf.readDouble();
            var y = buf.readDouble();
            var z = buf.readDouble();
            var xRot = buf.readFloat();
            var yRot = buf.readFloat();
            var yHeadRot = buf.readFloat();
            var deltaX = buf.readDouble();
            var deltaY = buf.readDouble();
            var deltaZ = buf.readDouble();
            // Retain this buffer so we can use it in the queued task (EntitySpawnExtension)
            buf.retain();
            context.queue(() -> {
                var entityType = BuiltInRegistries.f_256780_.m_7942_(entityTypeId);
                if (entityType == null) {
                    throw new IllegalStateException("Entity type (" + entityTypeId + ") is unknown, spawning at (" + x + ", " + y + ", " + z + ")");
                }
                if (Minecraft.m_91087_().f_91073_ == null) {
                    throw new IllegalStateException("Client world is null!");
                }
                var entity = entityType.m_20615_(Minecraft.m_91087_().f_91073_);
                if (entity == null) {
                    throw new IllegalStateException("Created entity is null!");
                }
                entity.m_20084_(uuid);
                entity.m_20234_(id);
                entity.m_217006_(x, y, z);
                entity.m_6027_(x, y, z);
                entity.m_146926_(xRot);
                entity.m_146922_(yRot);
                entity.m_5616_(yHeadRot);
                entity.m_5618_(yHeadRot);
                if (entity instanceof EntitySpawnExtension ext) {
                    ext.loadAdditionalSpawnData(buf);
                }
                buf.release();
                Minecraft.m_91087_().f_91073_.m_104739_(entity);
                entity.m_6001_(deltaX, deltaY, deltaZ);
            });
        }
    }
}
